const KEY = 'vernacular-eduai-state-v1'

const seed = {
  profile: null,
  progress: { xp: 0, streak: 0, quizzes: 0, avgScore: 0, lessons: 0, flashcards: 0 },
  notes: [],
  history: [],
  achievements: [],
  classes: [],
  assignments: [],
  role: 'student',
  engineMode: 'auto'
}

export function loadState() {
  try {
    return { ...seed, ...JSON.parse(localStorage.getItem(KEY) || '{}') }
  } catch {
    return { ...seed }
  }
}

export function saveState(state) {
  localStorage.setItem(KEY, JSON.stringify(state))
}

export function resetState() {
  localStorage.removeItem(KEY)
  return { ...seed }
}

export { KEY }
