const templates = {
  Plants: {
    English: {
      lesson: `# Plants Around Us\n\nPlants are living things. They need sunlight, water, air and nutrients to grow.\n\n## Parts of a plant\n- Roots hold the plant in the soil and take in water.\n- Stem supports the plant and carries water.\n- Leaves make food using sunlight.\n- Flowers help plants make seeds.\n\n### Remember 🌱\nRoots → Stem → Leaves → Flower → Seed\n\n### Tiny activity\nFind a plant near you and point to its roots, stem and leaves.`,
      tutor: `Plants are living things that grow. 🌱 A plant usually has roots, a stem and leaves. Leaves make food using sunlight. Ask me about any part and I’ll explain it with a simple example.`,
      quiz: [
        ['Which part takes in water from the soil?', ['Leaf', 'Root', 'Flower', 'Fruit'], 1],
        ['Which part makes food using sunlight?', ['Leaf', 'Root', 'Seed', 'Stem'], 0],
        ['What does the stem mainly do?', ['It supports the plant', 'It sleeps', 'It makes rain', 'It becomes soil'], 0],
        ['What can grow into a new plant?', ['Seed', 'Stone', 'Glass', 'Cloud'], 0],
        ['Plants need which of these to grow?', ['Sunlight', 'Water', 'Air', 'All of these'], 3]
      ]
    },
    Tamil: {
      lesson: `# நம்மைச் சுற்றியுள்ள தாவரங்கள் 🌱\n\nதாவரங்கள் உயிருள்ளவை. அவை வளர சூரிய ஒளி, தண்ணீர், காற்று மற்றும் ஊட்டச்சத்துகள் தேவை.\n\n## தாவரத்தின் பகுதிகள்\n- வேர் மண்ணிலிருந்து தண்ணீரை எடுத்துக்கொள்கிறது.\n- தண்டு தாவரத்தைத் தாங்குகிறது.\n- இலைகள் சூரிய ஒளியைப் பயன்படுத்தி உணவை உருவாக்குகின்றன.\n- பூக்கள் விதைகள் உருவாக உதவுகின்றன.\n\n### நினைவில் கொள் 💚\nவேர் → தண்டு → இலை → பூ → விதை`,
      tutor: `தாவரம் ஒரு உயிருள்ள உயிரினம். 🌱 வேர்கள் தண்ணீரை எடுத்துக்கொள்கின்றன; தண்டு தாவரத்தைத் தாங்குகிறது; இலைகள் சூரிய ஒளியால் உணவை உருவாக்குகின்றன.`,
      quiz: [
        ['மண்ணிலிருந்து தண்ணீரை எடுக்கும் பகுதி எது?', ['இலை', 'வேர்', 'பூ', 'விதை'], 1],
        ['சூரிய ஒளியைப் பயன்படுத்தி உணவு உருவாக்குவது எது?', ['இலை', 'வேர்', 'விதை', 'தண்டு'], 0],
        ['தண்டின் முக்கிய பணி என்ன?', ['தாவரத்தைத் தாங்குதல்', 'தூங்குதல்', 'மழை உருவாக்குதல்', 'மண்ணாக மாறுதல்'], 0]
      ]
    }
  }
}

const genericQuiz = (subject, topic, language, count = 5) => {
  const base = language === 'Tamil'
    ? [
        [`${topic} பற்றி கற்றுக்கொண்ட பிறகு முதலில் நினைவில் கொள்ள வேண்டியது என்ன?`, ['முக்கிய கருத்து', 'எதுவும் இல்லை', 'வானிலை', 'விளையாட்டு'], 0],
        [`${subject} பாடத்தில் ${topic} ஏன் முக்கியம்?`, ['புரிந்துகொள்ள உதவுகிறது', 'நினைவில் வைக்க வேண்டாம்', 'அது தேவையற்றது', 'அது ஒரு விளையாட்டு'], 0],
        [`ஒரு புதிய கருத்தை கற்க சிறந்த வழி எது?`, ['புரிந்து கொண்டு பயிற்சி செய்வது', 'பார்க்காமல் இருப்பது', 'தவிர்ப்பது', 'யூகிப்பது'], 0],
        [`பதில் தெரியாவிட்டால் என்ன செய்யலாம்?`, ['கேள்வி கேட்டு விளக்கம் பெறலாம்', 'படிப்பை நிறுத்தலாம்', 'எதையும் எழுதாமல் இருக்கலாம்', 'தவறாகவே விட்டுவிடலாம்'], 0],
        [`பயிற்சி செய்வதால் என்ன கிடைக்கும்?`, ['நம்பிக்கை மற்றும் புரிதல்', 'குறைந்த அறிவு', 'குழப்பம் மட்டும்', 'எதுவும் இல்லை'], 0]
      ]
    : [
        [`Why is ${topic} important in ${subject}?`, ['It helps us understand the idea', 'It is only a game', 'It is never useful', 'We should avoid it'], 0],
        [`What is a good way to learn ${topic}?`, ['Understand and practise', 'Skip examples', 'Guess everything', 'Never ask questions'], 0],
        ['What should you do when you do not understand?', ['Ask for a simple explanation', 'Stop learning', 'Ignore it', 'Hide the question'], 0],
        ['What does practice improve?', ['Understanding and confidence', 'Confusion only', 'Nothing', 'Sleep'], 0],
        ['Which learning habit is useful?', ['Small daily practice', 'Never revise', 'Avoid mistakes', 'Do only one question'], 0]
      ]
  return base.slice(0, Math.max(1, Math.min(count, base.length)))
}

export async function askAI({ mode, prompt, language = 'English', context = '', engine = 'auto' }) {
  if (engine === 'offline') return { source: 'demo', engine: 'offline', text: localAI({ mode, prompt, language, context }) }

  try {
    const response = await fetch('/api/ai', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ mode, prompt, language, context })
    })
    const data = await response.json()
    if (data?.ok && data.text) return { source: 'ai', engine: 'online', text: data.text }
  } catch (_) {
    // Use local fallback so the demo remains fully usable without credentials/network.
  }
  return { source: 'demo', engine: 'offline', text: localAI({ mode, prompt, language, context }) }
}

export function localAI({ mode, prompt, language }) {
  const lower = (prompt || '').toLowerCase()
  const topic = extractAfter(prompt, /topic\s*[:=-]?\s*/i) || prompt?.trim() || 'Today’s topic'

  if (mode === 'lesson') {
    const known = Object.keys(templates).find(k => lower.includes(k.toLowerCase()))
    return templates[known]?.[language]?.lesson ||
      (language === 'Tamil'
        ? `# ${topic}\n\nஇது ${topic} பற்றிய எளிய பாடம். முக்கிய கருத்தை படிப்படியாகப் புரிந்து கொள்ளலாம்.\n\n### எளிய விளக்கம்\n${topic} என்ற கருத்தை ஒரு தினசரி வாழ்க்கை உதாரணத்துடன் நினைவில் கொள்ளுங்கள்.\n\n### பயிற்சி\nஒரு உதாரணத்தை நீங்களே சொல்லிப் பாருங்கள்.`
        : `# ${topic}\n\nHere is a simple primary-level lesson on **${topic}**.\n\n## Simple idea\nUnderstand the main idea first, then connect it to a real-life example.\n\n## Try it\nGive one example of ${topic} from your everyday life.`)
  }

  if (mode === 'quiz') {
    const known = Object.keys(templates).find(k => lower.includes(k.toLowerCase()))
    return JSON.stringify(templates[known]?.[language]?.quiz || genericQuiz('General', topic, language, 5))
  }

  if (mode === 'translate') {
    return `[${language} demo translation]\n\n${prompt}`
  }

  if (mode === 'flashcard') {
    return JSON.stringify([
      { front: topic, back: language === 'Tamil' ? `${topic} என்பதன் எளிய கருத்து.` : `A simple definition of ${topic}.` },
      { front: 'Example', back: language === 'Tamil' ? `${topic}க்கு ஒரு தினசரி வாழ்க்கை உதாரணம்.` : `A real-life example of ${topic}.` },
      { front: 'Remember', back: language === 'Tamil' ? 'சிறிது சிறிதாக கற்று தினமும் பயிற்சி செய்.' : 'Learn a little and practise every day.' }
    ])
  }

  if (mode === 'homework') {
    return language === 'Tamil'
      ? `### வீட்டுப்பாடம் – ${topic}\n1. ${topic} பற்றி 3 முக்கிய குறிப்புகளை எழுதுங்கள்.\n2. ஒரு தினசரி வாழ்க்கை உதாரணம் கண்டுபிடியுங்கள்.\n3. உங்களுக்கே ஒரு சிறிய கேள்வி உருவாக்குங்கள்.`
      : `### Homework – ${topic}\n1. Write 3 key points about ${topic}.\n2. Find one real-life example.\n3. Create one simple question for yourself.`
  }

  if (lower.includes('hello') || lower.includes('hi')) {
    return language === 'Tamil' ? 'வணக்கம்! 👋 இன்று என்ன கற்க விரும்புகிறாய்?' : 'Hello! 👋 What would you like to learn today?'
  }

  const known = Object.keys(templates).find(k => lower.includes(k.toLowerCase()))
  return templates[known]?.[language]?.tutor ||
    (language === 'Tamil'
      ? `${topic} பற்றி எளிய முறையில் விளக்குகிறேன். முதலில் முக்கிய கருத்தை புரிந்துகொண்டு, பின்னர் ஒரு உதாரணத்தைப் பார்ப்போம். உன் கேள்வியை தொடர்ந்து கேள்! 😊`
      : `Let’s learn **${topic}** step by step. First, understand the main idea, then connect it to a simple example. Keep asking questions! 😊`)
}

function extractAfter(value, regex) {
  const match = String(value || '').match(regex)
  return match?.[0] ? String(value).slice(match.index + match[0].length).trim() : ''
}
