import { useEffect, useMemo, useRef, useState } from 'react'
import { NavLink, Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom'
import { askAI, localAI } from './ai'
import { loadState, resetState, saveState } from './storage'
import { allFeatures, featureCategories } from './features'
import {
  ArrowRight, Award, Bell, BookOpen, BookOpenCheck, Brain, BrainCircuit, Check,
  CheckCircle2, ChevronRight, ClipboardCheck, ClipboardList, Cloud, Download,
  FileText, Flame, Gamepad2, GraduationCap, Heart, Home, Languages, Lightbulb,
  LockKeyhole, LogOut, MapPin, Menu, Mic, Network, Paperclip, Play, Plus,
  QrCode, RefreshCw, Search, Server, Settings, ShieldCheck, Smartphone,
  Sparkles, Star, Target, Trophy, Upload, User, Users, UsersRound, Volume2,
  WandSparkles, Wifi, WifiOff, X, Zap
} from 'lucide-react'

const LANGUAGES = ['English', 'Tamil', 'Hindi', 'Telugu', 'Kannada', 'Malayalam', 'Santhali', 'Mundari', 'Ho']
const SUBJECTS = ['Maths', 'Science / EVS', 'English', 'General Knowledge', 'Computer Basics']
const GRADES = ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5']

const roleMeta = {
  student: { label: 'Student', icon: '🧒', home: '/dashboard', color: 'sun' },
  teacher: { label: 'Teacher', icon: '🧑‍🏫', home: '/teacher', color: 'aqua' },
  parent: { label: 'Parent / Guardian', icon: '👨‍👩‍👧', home: '/parent-dashboard', color: 'pink' },
  admin: { label: 'School / Admin', icon: '🏫', home: '/admin', color: 'violet' }
}

const demoRouteMap = {
  level: '/progress', gap: '/progress', path: '/lessons', bilingual: '/translator', voice: '/voice',
  'teacher-voice': '/voice', blackboard: '/blackboard', docs: '/documents', visual: '/flashcards',
  fun: '/stories', quiz: '/quiz', qr: '/qr', teacher: '/teacher', parent: '/parent-dashboard',
  monitoring: '/admin', offline: '/dual-engine', schoolbox: '/dual-engine', lowcost: '/dual-engine',
  safetab: '/safetab', sos: '/safetab', community: '/translator', privacy: '/settings'
}

function App() {
  const [state, setState] = useState(loadState)
  const [loadingAI, setLoadingAI] = useState(false)
  const [toast, setToast] = useState('')
  const [online, setOnline] = useState(() => typeof navigator !== 'undefined' ? navigator.onLine : true)

  useEffect(() => saveState(state), [state])
  useEffect(() => {
    const on = () => setOnline(true)
    const off = () => setOnline(false)
    window.addEventListener('online', on); window.addEventListener('offline', off)
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off) }
  }, [])
  useEffect(() => {
    if (!toast) return
    const id = setTimeout(() => setToast(''), 2600)
    return () => clearTimeout(id)
  }, [toast])

  const update = patch => setState(prev => ({ ...prev, ...patch }))
  const addXP = (amount, type = 'activity') => {
    setState(prev => {
      const progress = { ...prev.progress, xp: prev.progress.xp + amount, streak: Math.max(1, prev.progress.streak) }
      const earned = []
      if (progress.xp >= 50) earned.push('Quick Learner')
      if (progress.xp >= 100) earned.push('Super Star')
      if (progress.streak >= 3) earned.push('Streak Star')
      if (progress.quizzes >= 3) earned.push('Quiz Master')
      return { ...prev, progress, achievements: Array.from(new Set([...prev.achievements, ...earned])), history: [{ type, amount, at: new Date().toISOString() }, ...prev.history].slice(0, 60) }
    })
  }
  const submitQuiz = score => {
    setState(prev => {
      const q = prev.progress.quizzes + 1
      const avg = Math.round(((prev.progress.avgScore * prev.progress.quizzes) + score) / q)
      const next = { ...prev.progress, quizzes: q, avgScore: avg, xp: prev.progress.xp + Math.max(5, score), streak: Math.max(1, prev.progress.streak) }
      const achievements = new Set(prev.achievements)
      if (q >= 3) achievements.add('Quiz Master')
      return { ...prev, progress: next, achievements: [...achievements], history: [{ type: 'quiz', score, at: new Date().toISOString() }, ...prev.history].slice(0, 60) }
    })
  }

  const profileReady = !!state.profile
  const role = state.role || 'student'
  const homeForRole = roleMeta[role]?.home || '/dashboard'
  const login = profile => {
    setState(prev => ({ ...prev, ...profile, progress: { ...prev.progress, streak: Math.max(1, prev.progress.streak) } }))
    setToast(`Welcome, ${profile.profile.name}! Your ${roleMeta[profile.role]?.label || 'learning'} space is ready.`)
  }
  const logout = () => {
    setState(prev => ({ ...prev, profile: null, role: 'student' }))
    setToast('Signed out. Your demo data stays on this device.')
  }
  const reset = () => { setState(resetState()); setToast('Demo data reset') }
  const renderShell = children => <AppShell state={state} online={online} onReset={reset} onLogout={logout}>{children}</AppShell>

  return (
    <>
      <Routes>
        <Route path="/" element={profileReady ? <Navigate to={homeForRole} replace /> : <LoginPage onLogin={login} />} />
        <Route path="/dashboard" element={renderShell(<Dashboard state={state} online={online} />)} />
        <Route path="/features" element={renderShell(<FeatureCenter />)} />
        <Route path="/dual-engine" element={renderShell(<DualEnginePage state={state} online={online} update={update} />)} />
        <Route path="/lessons" element={renderShell(<Lessons state={state} setLoadingAI={setLoadingAI} addXP={addXP} />)} />
        <Route path="/tutor" element={renderShell(<Tutor state={state} setLoadingAI={setLoadingAI} />)} />
        <Route path="/quiz" element={renderShell(<Quiz state={state} submitQuiz={submitQuiz} setLoadingAI={setLoadingAI} />)} />
        <Route path="/translator" element={renderShell(<Translator state={state} setLoadingAI={setLoadingAI} />)} />
        <Route path="/flashcards" element={renderShell(<Flashcards state={state} addXP={addXP} setLoadingAI={setLoadingAI} />)} />
        <Route path="/stories" element={renderShell(<StoriesGames state={state} addXP={addXP} />)} />
        <Route path="/notes" element={renderShell(<Notes state={state} update={update} setToast={setToast} />)} />
        <Route path="/progress" element={renderShell(<Progress state={state} />)} />
        <Route path="/achievements" element={renderShell(<Achievements state={state} />)} />
        <Route path="/parent" element={renderShell(<ParentCorner state={state} />)} />
        <Route path="/settings" element={renderShell(<SettingsPage state={state} update={update} setToast={setToast} />)} />
        <Route path="/voice" element={renderShell(<VoiceAssistant state={state} />)} />
        <Route path="/blackboard" element={renderShell(<BlackboardAssistant />)} />
        <Route path="/documents" element={renderShell(<DocumentTool state={state} setLoadingAI={setLoadingAI} />)} />
        <Route path="/qr" element={renderShell(<QRScanner />)} />
        <Route path="/teacher" element={renderShell(<TeacherDashboard state={state} update={update} />)} />
        <Route path="/parent-dashboard" element={renderShell(<ParentDashboardFull state={state} />)} />
        <Route path="/admin" element={renderShell(<AdminDashboard state={state} />)} />
        <Route path="/safetab" element={renderShell(<SafeTabHub state={state} />)} />
        <Route path="*" element={<Navigate to={profileReady ? homeForRole : '/'} replace />} />
      </Routes>
      {toast && <div className="toast"><CheckCircle2 size={17} /> {toast}</div>}
      {loadingAI && <div className="ai-busy"><Sparkles size={16} className="spin" /> EduAI is thinking…</div>}
    </>
  )
}

function AppShell({ state, online, onReset, onLogout, children }) {
  const [open, setOpen] = useState(false)
  const nav = useNavigate()
  const location = useLocation()
  const profile = state.profile || { name: 'Learner', grade: 'Grade 1', language: 'English' }
  const items = [
    ['/dashboard', 'Home', Home], ['/features', '160 Features', Sparkles], ['/dual-engine', 'Dual Engine', Network],
    ['/lessons', 'AI Lessons', BookOpen], ['/tutor', 'AI Tutor', BrainCircuit], ['/quiz', 'Quiz + Practice', ClipboardList],
    ['/translator', 'Translator', Languages], ['/flashcards', 'Flashcards', Gamepad2], ['/stories', 'Stories + Games', Star],
    ['/progress', 'Progress', Target], ['/achievements', 'Badges', Trophy], ['/notes', 'My Notes', FileText]
  ]
  const tools = [['/voice', 'Voice AI', Mic], ['/blackboard', 'Blackboard AI', WandSparkles], ['/documents', 'Upload → Lesson', Paperclip], ['/qr', 'QR Learning', QrCode], ['/safetab', 'SafeTab + SOS', ShieldCheck]]
  return (
    <div className="app-shell">
      <aside className={`sidebar ${open ? 'sidebar-open' : ''}`}>
        <div className="brand" onClick={() => nav('/dashboard')}>
          <div className="brand-mark big">📚</div>
          <div><strong>Vernacular</strong><span>EduAI</span></div>
        </div>
        <div className="engine-mini">
          <div className={`engine-orb ${online ? 'online' : 'offline'}`}>{online ? <Wifi size={15}/> : <WifiOff size={15}/>}</div>
          <div><strong>{online ? 'Online + Offline' : 'Offline mode'}</strong><span>{online ? 'Auto fallback ready' : 'Local engine active'}</span></div>
        </div>
        <div className="profile-mini">
          <div className="avatar">{profile.name?.slice(0, 1)?.toUpperCase() || 'L'}</div>
          <div><strong>{profile.name}</strong><span>{roleMeta[state.role]?.label || 'Student'} · {profile.grade || 'School'}</span></div>
        </div>
        <nav className="nav-list">
          {items.map(([path, label, Icon]) => <NavLink key={path} to={path} onClick={() => setOpen(false)} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}><Icon size={18}/><span>{label}</span></NavLink>)}
        </nav>
        <div className="nav-section-label">AI & Classroom Tools</div>
        <nav className="nav-list">
          {tools.map(([path, label, Icon]) => <NavLink key={path} to={path} onClick={() => setOpen(false)} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}><Icon size={18}/><span>{label}</span></NavLink>)}
        </nav>
        <div className="nav-section-label">Role Views</div>
        <nav className="nav-list role-nav">
          <NavLink to="/teacher" onClick={() => setOpen(false)} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}><UsersRound size={18}/><span>Teacher</span></NavLink>
          <NavLink to="/parent-dashboard" onClick={() => setOpen(false)} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}><Heart size={18}/><span>Parent</span></NavLink>
          <NavLink to="/admin" onClick={() => setOpen(false)} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}><Server size={18}/><span>School / Admin</span></NavLink>
        </nav>
        <div className="sidebar-bottom">
          <div className="side-actions"><button className="outline-btn" onClick={onReset}><RefreshCw size={15}/> Reset</button><button className="outline-btn" onClick={onLogout}><LogOut size={15}/> Sign out</button></div>
          <div className="made-with">🌈 Built for primary learners • Frontend demo</div>
        </div>
      </aside>
      {open && <div className="scrim" onClick={() => setOpen(false)} />}
      <section className="main-area">
        <header className="topbar">
          <button className="icon-btn mobile-only" onClick={() => setOpen(v => !v)}><Menu size={22}/></button>
          <div className="topbar-note"><span className="crumb-dot">●</span> Learn · Play · Practice · Grow</div>
          <div className="top-actions">
            <div className={`status-pill ${online ? 'good' : 'warn'}`}>{online ? <Wifi size={14}/> : <WifiOff size={14}/>} {online ? 'Online AI + local fallback' : 'Offline local engine'}</div>
            <NavLink to="/settings" className="top-profile"><User size={18}/></NavLink>
          </div>
        </header>
        <main className="content">{children}</main>
      </section>
    </div>
  )
}

function LoginPage({ onLogin }) {
  const [role, setRole] = useState('student')
  const [name, setName] = useState('')
  const [grade, setGrade] = useState('Grade 3')
  const [language, setLanguage] = useState('Tamil')
  const [schoolCode, setSchoolCode] = useState('DEMO-2026')
  const [pin, setPin] = useState('1234')
  const [error, setError] = useState('')
  const submit = e => {
    e.preventDefault()
    if (!name.trim()) { setError('Please enter a name to start the demo.'); return }
    setError('')
    onLogin({ role, profile: { name: name.trim(), grade, language, schoolCode, pin, syllabus: 'School Demo', subject: 'Science / EVS', parent: 'Family Account', state: 'Jharkhand / Tamil Nadu demo', country: 'India' } })
  }
  const guest = () => onLogin({ role:'student', profile:{ name:'Aarav', grade:'Grade 3', age:'8', language:'Tamil', schoolCode:'DEMO-2026', pin:'1234', syllabus:'Primary Demo', subject:'Science / EVS', parent:'Family Account', state:'Demo', country:'India' } })
  return (
    <div className="login-page">
      <div className="bubble b1">🌈</div><div className="bubble b2">⭐</div><div className="bubble b3">🦋</div><div className="bubble b4">📚</div>
      <div className="login-layout">
        <section className="login-hero">
          <div className="hero-logo">📚</div>
          <div className="hero-kicker">AI-powered vernacular pedagogy</div>
          <h1>Learn in your language.<br/><span>Learn without limits.</span></h1>
          <p>Vernacular EduAI is a colourful primary-learning portal combining bilingual AI, local language support, teacher tools, family engagement and an offline + online dual engine.</p>
          <div className="hero-feature-strip"><span>🧠 Adaptive</span><span>🌍 Vernacular</span><span>🎮 Playful</span><span>📴 Offline-first</span><span>🛡️ Child-safe</span></div>
          <div className="hero-stat-row"><div><strong>160</strong><span>feature surfaces</span></div><div><strong>22</strong><span>solution modules</span></div><div><strong>2</strong><span>AI engines</span></div></div>
        </section>
        <section className="login-card">
          <div className="login-head"><div><span className="eyebrow">WELCOME</span><h2>Enter the learning world 🚀</h2><p>Choose who you are and start the presentation demo.</p></div><div className="tiny-safe"><ShieldCheck size={15}/> SafeTab</div></div>
          <div className="role-grid">{Object.entries(roleMeta).map(([id, meta]) => <button key={id} className={`role-card ${role===id?'selected':''} ${meta.color}`} onClick={() => setRole(id)} type="button"><span>{meta.icon}</span><strong>{meta.label}</strong><small>{id==='student'?'Primary learner':id==='teacher'?'Classroom control':id==='parent'?'Family companion':'School view'}</small></button>)}</div>
          <form onSubmit={submit} className="login-form">
            <label>{role==='student'?'Student name':role==='teacher'?'Teacher name':role==='parent'?'Parent / guardian':'School / admin name'}<input value={name} onChange={e=>setName(e.target.value)} placeholder={role==='student'?'e.g., Meena':'e.g., Anitha'} /></label>
            {role==='student' ? <div className="form-grid two"> <label>Grade<select value={grade} onChange={e=>setGrade(e.target.value)}>{GRADES.map(g=><option key={g}>{g}</option>)}</select></label><label>Mother tongue<select value={language} onChange={e=>setLanguage(e.target.value)}>{LANGUAGES.map(l=><option key={l}>{l}</option>)}</select></label></div> : <div className="form-grid two"><label>School code<input value={schoolCode} onChange={e=>setSchoolCode(e.target.value)} /></label><label>Demo PIN<input value={pin} onChange={e=>setPin(e.target.value)} inputMode="numeric" /></label></div>}
            {error && <div className="error-box">⚠️ {error}</div>}
            <label className="check-line"><input type="checkbox" defaultChecked/> I agree to the demo’s child-safe, consent-based learning use.</label>
            <button className="primary-btn login-submit" type="submit"><span>Enter portal</span><ArrowRight size={18}/></button>
          </form>
          <div className="login-divider"><span>or</span></div>
          <button className="guest-btn" onClick={guest}>✨ Try the primary-student demo instantly</button>
          <p className="login-note">No real student account is created. Demo state is stored locally in the browser.</p>
        </section>
      </div>
    </div>
  )
}

function PageHeader({ eyebrow, title, description, action }) {
  return <div className="page-header"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action && <div>{action}</div>}</div>
}
function SectionTitle({ icon='✨', title, subtitle }) { return <div className="section-title"><div className="section-icon">{icon}</div><div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div></div> }
function Card({ children, className='' }) { return <section className={`card ${className}`}>{children}</section> }
function Bar({ label, value, emoji='📊' }) { return <div className="bar-row"><span>{emoji} {label}</span><div><i style={{ width:`${Math.max(0,Math.min(100,value))}%` }}/></div><b>{value}%</b></div> }
function MiniTag({ children, tone='soft' }) { return <span className={`mini-tag ${tone}`}>{children}</span> }

function Dashboard({ state, online }) {
  const profile = state.profile || {}
  const topCats = featureCategories.slice(0, 8)
  const quick = [['AI Lessons','/lessons','📚','Make a simple lesson'],['AI Tutor','/tutor','🤖','Ask anything'],['Quiz Time','/quiz','🎯','Practice 5 questions'],['Translator','/translator','🌍','Bridge languages'],['Stories + Games','/stories','🎮','Learn through play'],['Dual Engine','/dual-engine','📴','Offline + online']]
  return <>
    <div className="welcome-hero">
      <div className="hero-copy"><div className="hero-chip">{online ? '☁️ ONLINE + 📴 OFFLINE READY' : '📴 OFFLINE LEARNING ACTIVE'}</div><h2>Hello {profile.name || 'Learner'}! 🌟<br/>Let’s make today a learning adventure.</h2><p>Grade {profile.grade?.replace('Grade ','') || '3'} • {profile.language || 'Tamil'} • Primary Learning Space</p><div className="hero-actions"><NavLink className="primary-btn white-btn" to="/lessons"><Sparkles size={17}/> Start with AI Lesson</NavLink><NavLink className="glass-btn" to="/features">Explore all 160 features <ArrowRight size={16}/></NavLink></div></div><div className="hero-scene"><span className="planet">🌍</span><span className="book">📖</span><span className="child">🧒🏽</span><span className="stars">✦ ✦ ✦</span></div>
    </div>
    <div className="metric-grid colorful-metrics"><Metric icon="⭐" label="XP" value={state.progress.xp} tone="sun"/><Metric icon="🔥" label="Streak" value={`${state.progress.streak || 1} days`} tone="orange"/><Metric icon="🎯" label="Quiz avg." value={`${state.progress.avgScore || 0}%`} tone="aqua"/><Metric icon="📚" label="Lessons" value={state.progress.lessons} tone="pink"/><Metric icon="🏆" label="Badges" value={state.achievements.length} tone="violet"/></div>
    <div className="dashboard-grid">
      <Card><SectionTitle icon="🚀" title="Pick your next adventure" subtitle="Every activity can use the online AI engine or local offline engine."/><div className="quick-grid big">{quick.map(([label,path,emoji,small])=><NavLink to={path} className="quick-card colourful" key={path}><span>{emoji}</span><div><strong>{label}</strong><small>{small}</small></div><ChevronRight size={16}/></NavLink>)}</div></Card>
      <Card><SectionTitle icon="🧭" title="Your learning path" subtitle="A simple bridge from today’s level to the next milestone."/><div className="learning-path"><PathStep n="1" title="Check my level" text="3-question baseline" done={state.progress.quizzes>0}/><PathStep n="2" title="Learn + translate" text="Bilingual lesson" done={state.progress.lessons>0}/><PathStep n="3" title="Practise + recover" text="Adaptive quiz" done={state.progress.avgScore>0}/><PathStep n="4" title="Celebrate" text="XP + badges" done={state.achievements.length>0}/></div></Card>
    </div>
    <Card><div className="section-heading-row"><SectionTitle icon="🌈" title="Solution pillars" subtitle="The portal is much bigger than a quiz app."/><NavLink to="/features" className="soft-btn">See all 22 modules</NavLink></div><div className="category-strip">{topCats.map(c=><NavLink to={`/features?cat=${c.id}`} className={`category-tile ${c.color}`} key={c.id}><div className="category-emoji">{c.emoji}</div><strong>{c.title}</strong><small>{c.features.length} features</small></NavLink>)}</div></Card>
    <Card className="dual-banner"><div><MiniTag tone="green">DUAL ENGINE</MiniTag><h2>Learn even when the internet disappears.</h2><p>Offline packs, local storage and nearby Wi-Fi sync keep core learning moving. When a connection is available, cloud AI adds richer generation and backup.</p><div className="engine-pair"><div className="engine-card local"><WifiOff/><strong>Offline Local Engine</strong><span>lessons • quizzes • notes • progress • attendance</span></div><div className="engine-link">⇄</div><div className="engine-card cloud"><Cloud/><strong>Online AI Engine</strong><span>AI generation • translation • voice • backup</span></div></div></div><NavLink to="/dual-engine" className="primary-btn">View architecture <ArrowRight size={17}/></NavLink></Card>
  </>
}
function Metric({ icon, label, value, tone }) { return <Card className={`metric-card ${tone}`}><div className="metric-icon">{icon}</div><div><strong>{value}</strong><span>{label}</span></div></Card> }
function PathStep({n,title,text,done}) { return <div className={`path-step ${done?'done':''}`}><div className="path-number">{done?<Check size={16}/>:n}</div><div><strong>{title}</strong><small>{text}</small></div><span>{done?'✓':'→'}</span></div> }

function FeatureCenter() {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('all')
  const [selected, setSelected] = useState(null)
  const nav = useNavigate()
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    return allFeatures.filter(f => (category==='all'||f.categoryId===category) && (!q || `${f.number} ${f.name} ${f.category}`.toLowerCase().includes(q)))
  }, [query, category])
  const selectedFeature = selected ? allFeatures.find(f=>f.number===selected) : null
  return <>
    <PageHeader eyebrow="THE FULL PRODUCT SURFACE" title="🌈 160-Feature EduAI Portal" description="Every solution feature from the Vernacular EduAI concept is represented here as a colourful, presentation-ready frontend surface. Tap a card to see how it fits the solution." action={<MiniTag tone="purple">22 solution modules</MiniTag>}/>
    <Card className="feature-hero"><div><MiniTag tone="yellow">ALL FEATURES</MiniTag><h2>One portal. Many learning pathways.</h2><p>Use the search box or module filter. Features are numbered to map directly to your PPT and problem-statement solution.</p></div><div className="feature-count"><strong>160</strong><span>feature titles</span></div></Card>
    <Card className="feature-filter"><div className="search-box"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search: SafeTab, Santhali, quiz, offline, parent…"/></div><div className="pill-scroll"><button className={`filter-pill ${category==='all'?'active':''}`} onClick={()=>setCategory('all')}>✨ All</button>{featureCategories.map(c=><button key={c.id} className={`filter-pill ${category===c.id?'active':''}`} onClick={()=>setCategory(c.id)}>{c.emoji} {c.title}</button>)}</div></Card>
    <div className="feature-layout">
      <div className="feature-list-grid">{filtered.map(f=><button className={`feature-tile ${f.color}`} key={f.id} onClick={()=>setSelected(f.number)}><div className="feature-index">#{f.number}</div><div className="feature-icon">{f.emoji}</div><div className="feature-body"><strong>{f.name}</strong><small>{f.category}</small></div><ChevronRight size={16}/></button>)}{filtered.length===0&&<Card><EmptyState icon="🔎" title="No feature found" text="Try a broader search term."/></Card>}</div>
      {selectedFeature && <div className="feature-detail-wrap"><Card className="feature-detail sticky-card"><button className="close-btn" onClick={()=>setSelected(null)}><X size={17}/></button><div className={`detail-art ${selectedFeature.color}`}><span>{selectedFeature.emoji}</span><b>#{selectedFeature.number}</b></div><MiniTag tone="soft">{selectedFeature.category}</MiniTag><h2>{selectedFeature.name}</h2><p>{featureDescription(selectedFeature)}</p><div className="detail-grid"><div><span>ENGINE</span><strong>{engineLabel(selectedFeature)}</strong></div><div><span>SURFACE</span><strong>Frontend demo</strong></div><div><span>USER</span><strong>{userLabel(selectedFeature.categoryId)}</strong></div><div><span>DATA</span><strong>Consent + local-first</strong></div></div><button className="primary-btn full-width" onClick={()=>nav(demoRouteMap[selectedFeature.categoryId] || '/dual-engine')}>Open demo surface <ArrowRight size={16}/></button></Card></div>}
    </div>
  </>
}
function featureDescription(f) {
  const c = f.categoryId
  const map = {
    bilingual:'A vernacular learning surface that can show the same concept in a familiar language, with culture-aware examples and teacher review.',
    level:'A learner-facing assessment surface that gathers evidence about starting level and turns it into the next learning action.',
    gap:'A visual diagnostic surface that connects wrong answers to topic gaps and recovery activities.',
    path:'A personalised pathway surface that recommends the next concept, practice level or remedial activity.',
    voice:'A speech-first learning surface for asking, explaining, listening and pronunciation practice.',
    'teacher-voice':'A teacher productivity surface that turns spoken classroom intent into structured content.',
    blackboard:'A vision/OCR surface for turning classroom board work into clean digital notes and lessons.',
    docs:'A multimodal upload surface for PDFs, presentations, documents and images.',
    visual:'A memory-building surface using visuals, audio and spaced repetition.',
    fun:'A joyful primary-learning surface combining stories, rhymes, games, XP and safe entertainment.',
    quiz:'An assessment surface with multiple activity types, automatic checking and bilingual feedback.',
    qr:'A fast bridge from printed school material into digital learning flows.',
    teacher:'A classroom command centre covering content, assignments, dashboards, videos and support signals.',
    parent:'A family companion surface for progress, homework guidance and approved updates.',
    monitoring:'An aggregate school/government reporting layer built around privacy-aware summaries.',
    offline:'Core learning continues locally even without internet, using cached packs and local storage.',
    schoolbox:'Nearby devices can exchange learning data locally and resolve sync changes safely.',
    lowcost:'A low-resource experience for affordable Android tablets and preloaded local learning content.',
    safetab:'A controlled school-device recovery workflow with identification, lock, recovery and authorised location actions.',
    sos:'A controlled emergency-contact workflow connecting student, teacher, parent and school safety roles.',
    community:'A human-in-the-loop language layer where native speakers and local communities help verify terms and context.',
    privacy:'A child-safe governance layer covering consent, access control, content review and responsible AI.'
  }
  return map[c] || 'A presentation-ready EduAI capability represented in the Vernacular EduAI product architecture.'
}
function engineLabel(f) {
  if (['offline','schoolbox','lowcost','safetab','sos'].includes(f.categoryId)) return 'Offline-first'
  if (['voice','teacher-voice','blackboard','docs','bilingual'].includes(f.categoryId)) return 'Dual engine'
  return 'Hybrid'
}
function userLabel(id) { if (['teacher','teacher-voice','blackboard','docs'].includes(id)) return 'Teacher'; if (['parent','sos'].includes(id)) return 'Parent'; if (['monitoring'].includes(id)) return 'School'; return 'Student' }

function DualEnginePage({ state, online, update }) {
  const mode = state.engineMode || 'auto'
  const setMode = engineMode => update({ engineMode })
  const offlineCore = ['Offline lessons','Quiz + homework queue','Notes + local portfolio','Attendance records','Progress cache','Shared-tablet profiles']
  const onlineBoost = ['AI lesson generation','AI tutor','Cloud translation','Voice intelligence','Video processing','Cloud backup']
  return <>
    <PageHeader eyebrow="CORE DIFFERENTIATOR" title="⚡ Offline + Online Dual Engine" description="Vernacular EduAI is designed as one product with two execution paths: a local engine for continuity and a cloud AI engine for richer intelligence." action={<MiniTag tone={online?'green':'yellow'}>{online?'NETWORK AVAILABLE':'AIRPLANE MODE'}</MiniTag>}/>
    <Card className="engine-toggle-card"><div><div className="eyebrow">DEMO CONTROL</div><h2>Choose how the demo behaves</h2><p>Auto uses online AI when available and falls back to local demo intelligence. The other modes force one path for your PPT demonstration.</p></div><div className="toggle-row">{[['auto','AUTO','🔁'],['online','ONLINE','☁️'],['offline','OFFLINE','📴']].map(([id,label,emoji])=><button key={id} className={`mode-btn ${mode===id?'active':''}`} onClick={()=>setMode(id)}><span>{emoji}</span><strong>{label}</strong><small>{id==='auto'?'Smart fallback':id==='online'?'Cloud AI':'On-device'}</small></button>)}</div></Card>
    <div className="engine-visual">
      <div className="engine-side local-engine"><div className="engine-title"><div className="engine-icon"><WifiOff/></div><div><MiniTag tone="green">ENGINE A</MiniTag><h2>Local Offline Engine</h2><p>Works without internet.</p></div></div><div className="engine-list">{offlineCore.map((x,i)=><div key={x}><span>{i+1}</span><strong>{x}</strong><CheckCircle2 size={15}/></div>)}</div><div className="device-stack"><span>📱 Tablet</span><span>💾 Local Pack</span><span>🗃️ Local DB</span></div></div>
      <div className="sync-core"><div className="sync-orb">⇄</div><strong>SYNC + FALLBACK</strong><small>When connectivity returns</small><div className="sync-line"/></div>
      <div className="engine-side cloud-engine"><div className="engine-title"><div className="engine-icon"><Cloud/></div><div><MiniTag tone="purple">ENGINE B</MiniTag><h2>Online AI Engine</h2><p>Expands capability when connected.</p></div></div><div className="engine-list">{onlineBoost.map((x,i)=><div key={x}><span>{i+1}</span><strong>{x}</strong><Zap size={15}/></div>)}</div><div className="device-stack"><span>☁️ AI API</span><span>🔊 Voice</span><span>🧠 Model</span></div></div>
    </div>
    <div className="flow-steps"><FlowStep num="01" title="Capture" text="Student answers, notes, attendance, teacher content"/><FlowStep num="02" title="Decide" text="Online available? Use cloud AI; otherwise stay local"/><FlowStep num="03" title="Learn" text="Show lesson, quiz, story, flashcard or recovery activity"/><FlowStep num="04" title="Queue" text="Store offline changes safely for later sync"/><FlowStep num="05" title="Sync" text="Resolve conflicts and back up only when allowed"/></div>
    <Card className="offline-model"><div className="section-heading-row"><SectionTitle icon="📅" title="Three-day offline + two-day online classroom model" subtitle="A simple storyboard for your PPT solution slide."/><MiniTag tone="green">5-DAY CYCLE</MiniTag></div><div className="day-grid"><div><b>DAY 1</b><span>📴 Offline lesson</span><small>Teacher-led + local pack</small></div><div><b>DAY 2</b><span>🎯 Offline practice</span><small>Quiz + homework queue</small></div><div><b>DAY 3</b><span>🏫 Offline classroom</span><small>Attendance + progress</small></div><div className="online-day"><b>DAY 4</b><span>☁️ Online AI</span><small>Generate + refresh content</small></div><div className="online-day"><b>DAY 5</b><span>🎬 Recorded / cloud</span><small>Download + sync + reports</small></div></div></Card>
    <Card><SectionTitle icon="🔐" title="Responsible engine rules" subtitle="Frontend demonstration of the intended control layer."/><div className="rule-grid"><Rule icon="✅" title="Teacher approval" text="Teacher/parent approved voice and entertainment surfaces."/><Rule icon="🧒" title="Child-safe" text="No ads, no unrestricted external content, controlled access."/><Rule icon="📴" title="Offline continuity" text="Core learning does not stop because connectivity is missing."/><Rule icon="🔄" title="Conflict-safe sync" text="Local changes queue until trusted synchronization is available."/></div></Card>
  </>
}
function FlowStep({num,title,text}) { return <div className="flow-step"><span>{num}</span><strong>{title}</strong><p>{text}</p></div> }
function Rule({icon,title,text}) { return <div className="rule-card"><span>{icon}</span><div><strong>{title}</strong><p>{text}</p></div></div> }

function Lessons({ state, setLoadingAI, addXP }) {
  const [topic, setTopic] = useState('Plants Around Us')
  const [subject, setSubject] = useState('Science / EVS')
  const [lesson, setLesson] = useState('')
  const generate = async () => { setLoadingAI(true); const res = await askAI({ mode:'lesson', prompt:`Topic: ${topic}\nSubject: ${subject}`, language:state.profile?.language || 'English', engine:state.engineMode||'auto' }); setLesson(res.text); setLoadingAI(false); addXP(10,'lesson'); }
  return <><PageHeader eyebrow="LEARN" title="📚 AI Lesson Maker" description="Generate primary-level lessons with local language support, examples and practice prompts."/><Card className="maker-card"><div className="form-grid two"><label>Topic<input value={topic} onChange={e=>setTopic(e.target.value)} /></label><label>Subject<select value={subject} onChange={e=>setSubject(e.target.value)}>{SUBJECTS.map(s=><option key={s}>{s}</option>)}</select></label></div><div className="suggestion-row"><span>Try a topic:</span>{['Water Cycle','Animals Around Us','Fractions','My Family'].map(x=><button className="chip-btn" key={x} onClick={()=>setTopic(x)}>{x}</button>)}</div><button className="primary-btn" onClick={generate}><Sparkles size={17}/> Generate colourful lesson</button></Card>{lesson&&<Card className="result-card"><div className="ai-ribbon">✨ PERSONALIZED • {state.profile?.language || 'English'} • {state.engineMode==='offline'?'OFFLINE':state.engineMode==='online'?'ONLINE':'AUTO'}</div><LessonView markdown={lesson}/></Card>}</>
}
function LessonView({markdown}) { return <div className="lesson-view"><pre>{markdown}</pre><div className="lesson-chips"><span>🧠 Key idea</span><span>🌱 Real-life example</span><span>🎯 Practice</span><span>🔊 Voice-ready</span></div></div> }

function Tutor({ state, setLoadingAI }) {
  const [messages, setMessages] = useState([{who:'ai',text:'Hello! 👋 Ask me anything. I can explain in simple words and use your selected language.'}])
  const [input, setInput] = useState('')
  const ask = async () => { if(!input.trim()) return; const q=input.trim(); setInput(''); setMessages(m=>[...m,{who:'user',text:q}]); setLoadingAI(true); const res=await askAI({mode:'tutor',prompt:q,language:state.profile?.language||'English',engine:state.engineMode||'auto'}); setLoadingAI(false); setMessages(m=>[...m,{who:'ai',text:res.text}]) }
  return <><PageHeader eyebrow="ASK EDUAI" title="🤖 AI Tutor" description="A friendly tutor that can explain, simplify, translate and encourage."/><Card className="chat-card"><div className="chat-window">{messages.map((m,i)=><div className={`chat-bubble ${m.who==='user'?'user':''}`} key={i}><div className="chat-avatar">{m.who==='user'?'🧒':'🤖'}</div><div>{m.text}</div></div>)}</div><div className="chat-compose"><textarea value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();ask()}}} placeholder="Ask: Explain photosynthesis like I am 8…"/><button className="primary-btn" onClick={ask}><ArrowRight size={18}/></button></div></Card></>
}

function Quiz({ state, submitQuiz }) {
  const questions = useMemo(()=>JSON.parse(localAI({mode:'quiz',prompt:'topic: Plants',language:state.profile?.language||'English'})),[state.profile?.language])
  const [index,setIndex]=useState(0); const [selected,setSelected]=useState(null); const [score,setScore]=useState(0); const [done,setDone]=useState(false)
  const current=questions[index]
  const choose=i=>setSelected(i)
  const next=()=>{ if(selected===null)return; const nextScore=score+(selected===current[2]?1:0); if(index===questions.length-1){setScore(nextScore);setDone(true);submitQuiz(Math.round(nextScore/questions.length*100))}else{setScore(nextScore);setIndex(i=>i+1);setSelected(null)} }
  if(done) return <><PageHeader eyebrow="CELEBRATE" title="🎉 Quiz complete!" description="Your answers have been added to the local progress record."/><Card className="result-celebration"><div className="celebrate-icon">🏆</div><h2>{Math.round(score/questions.length*100)}%</h2><p>{score} out of {questions.length} correct.</p><div className="role-buttons"><button className="primary-btn" onClick={()=>{setDone(false);setIndex(0);setScore(0);setSelected(null)}}>Play again</button><NavLink className="soft-btn" to="/progress">See my progress</NavLink></div></Card></>
  return <><PageHeader eyebrow="PRACTICE" title="🎯 Smart Quiz" description="Bilingual-ready questions with automatic evaluation and instant feedback."/><Card className="quiz-card"><div className="quiz-progress"><span>Question {index+1} of {questions.length}</span><div className="progress-track"><i style={{width:`${((index+1)/questions.length)*100}%`}}/></div></div><MiniTag tone="aqua">{state.profile?.language || 'English'} feedback</MiniTag><h2>{current[0]}</h2><div className="option-grid">{current[1].map((opt,i)=><button key={opt} className={`option ${selected===i?'selected':''}`} onClick={()=>choose(i)}><span>{String.fromCharCode(65+i)}</span><strong>{opt}</strong></button>)}</div><button className="primary-btn" disabled={selected===null} onClick={next}>{index===questions.length-1?'Finish quiz':'Next question'} <ArrowRight size={17}/></button></Card></>
}

function Translator({ state, setLoadingAI }) {
  const [from,setFrom]=useState('Hindi'); const [to,setTo]=useState(state.profile?.language||'Tamil'); const [text,setText]=useState(''); const [result,setResult]=useState('')
  const translate=async()=>{if(!text.trim())return;setLoadingAI(true);const res=await askAI({mode:'translate',prompt:text,language:`${to}`,context:`Translate from ${from} to ${to} with simple primary-friendly wording.`,engine:state.engineMode||'auto'});setResult(res.text);setLoadingAI(false)}
  return <><PageHeader eyebrow="LANGUAGE BRIDGE" title="🌍 Culture-Aware Translator" description="Hindi-to-tribal language bridge with Ho, Mundari and Santhali learning support surfaces."/><Card><div className="translate-grid"><label>From<select value={from} onChange={e=>setFrom(e.target.value)}><option>Hindi</option><option>English</option></select></label><button className="swap-btn" onClick={()=>{setFrom(to);setTo(from)}}>⇄</button><label>To<select value={to} onChange={e=>setTo(e.target.value)}>{LANGUAGES.filter(x=>x!=='English'||true).map(l=><option key={l}>{l}</option>)}</select></label></div><div className="two-text"><label>Input<textarea value={text} onChange={e=>setText(e.target.value)} placeholder="Type a sentence…"/></label><label>Translation<textarea value={result} readOnly placeholder="Your translated learning text appears here."/></label></div><div className="role-buttons"><button className="primary-btn" onClick={translate}><Languages size={17}/> Translate</button><MiniTag tone="purple">Community verification loop</MiniTag><MiniTag tone="yellow">Low-confidence review alert</MiniTag></div></Card><div className="language-row">{['Ho','Mundari','Santhali','Hindi Teacher','Khortha — future'].map((x,i)=><div className={`lang-card c${i}`} key={x}><span>{['🪶','🌿','🌾','🧑‍🏫','🧭'][i]}</span><strong>{x}</strong><small>{i===4?'Future expansion':'Learning support'}</small></div>)}</div></>
}

function Flashcards({state,addXP}) {
  const cards=[['Root','Takes in water from the soil. 🌱'],['Leaf','Makes food using sunlight. ☀️'],['Stem','Supports the plant and carries water.'],['Seed','Can grow into a new plant.']]
  const [i,setI]=useState(0); const [flip,setFlip]=useState(false)
  return <><PageHeader eyebrow="MEMORY PLAY" title="🎨 Flashcards" description="Picture, audio and spaced-repetition card surfaces for vocabulary and concepts."/><Card><div className="flash-wrap"><button className={`flash-card ${flip?'flipped':''}`} onClick={()=>setFlip(v=>!v)}><span>{flip?'BACK • REMEMBER':'FRONT • TAP TO FLIP'}</span><div className="flash-picture">{['🌱','🍃','🌿','🌻'][i]}</div><strong>{flip?cards[i][1]:cards[i][0]}</strong><small>{flip?'Audio-ready • Easy / Medium / Hard':'Picture-based flashcard'}</small></button><div className="flash-nav"><button className="soft-btn" onClick={()=>{setI(v=>(v+cards.length-1)%cards.length);setFlip(false)}}>←</button><span>{i+1} / {cards.length}</span><button className="soft-btn" onClick={()=>{setI(v=>(v+1)%cards.length);setFlip(false);addXP(2,'flashcard')}}>→</button></div><div className="role-buttons"><MiniTag tone="green">⏱ Spaced repetition</MiniTag><MiniTag tone="pink">🔊 Audio card</MiniTag><MiniTag tone="yellow">🎮 Vocabulary game</MiniTag></div></div></Card></>
}

function StoriesGames({addXP}) {
  const [mode,setMode]=useState('story');
  const story=mode==='story'
    ? `🌳 **The Little Seed and the Rain**\n\nA tiny seed slept under the soil. One morning, rain came. The seed drank water, felt the warm sun, and slowly opened its first leaf.\n\n**Practice:** Which helped the seed grow — water, sunlight, or both?`
    : `🎵 **Plant Parts Rhyme**\n\nRoots go down, stems stand tall,\nLeaves catch sunlight for us all!\nFlowers bloom and seeds can grow,\nNow you know — now you know!\n\n**Mini-game:** Point to each plant part around you.`
  return <><PageHeader eyebrow="EDUFUN AI" title="🎮 Stories, Rhymes & Games" description="Joyful primary content with teacher-reviewed and limited-screen-time surfaces."/><div className="story-mode-row">{[['story','📖','AI Story'],['rhyme','🎵','AI Rhyme'],['game','🧩','Mini-game']].map(([id,e,l])=><button key={id} className={`story-tab ${mode===id?'active':''}`} onClick={()=>setMode(id)}><span>{e}</span>{l}</button>)}</div><Card className="story-stage"><div className="story-illustration">{mode==='story'?'🌱':mode==='rhyme'?'🎶':'🧩'}</div><div className="story-copy"><MiniTag tone="pink">TEACHER-REVIEW READY</MiniTag><pre>{story}</pre><div className="role-buttons"><button className="primary-btn" onClick={()=>addXP(8,'edufun')}><Star size={17}/> Mark learned +8 XP</button><MiniTag tone="green">⏳ Screen-time friendly</MiniTag></div></div></Card></>
}

function Notes({state,update,setToast}) {
  const [title,setTitle]=useState(''); const [body,setBody]=useState('')
  const add=()=>{if(!title.trim())return;update({notes:[{id:Date.now(),title:title.trim(),body:body.trim(),at:new Date().toISOString()},...state.notes]});setTitle('');setBody('');setToast('Note saved locally ✓')}
  return <><PageHeader eyebrow="MY LEARNING" title="📝 Notes & Portfolio" description="Local notes, uploaded learning and portfolio-friendly evidence can stay available offline."/><div className="two-col"><Card><SectionTitle icon="✍️" title="Create a note"/><label>Title<input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Today I learned…"/></label><label>Notes<textarea value={body} onChange={e=>setBody(e.target.value)} placeholder="Write a simple idea, drawing prompt or homework reminder…"/></label><button className="primary-btn" onClick={add}><Plus size={17}/> Save note</button></Card><Card><SectionTitle icon="🗂️" title="Learning portfolio"/><div className="portfolio-stack"><PortfolioChip emoji="📚" title="AI lessons created" value={state.progress.lessons}/><PortfolioChip emoji="🎯" title="Quiz attempts" value={state.progress.quizzes}/><PortfolioChip emoji="🎨" title="Flashcards practised" value={state.progress.flashcards}/><PortfolioChip emoji="🏆" title="Badges earned" value={state.achievements.length}/></div></Card></div><Card><SectionTitle icon="🧾" title="Saved notes"/><div className="note-list">{state.notes.map(n=><div className="note-item" key={n.id}><div><strong>{n.title}</strong><p>{n.body || 'No extra text.'}</p><small>{new Date(n.at).toLocaleString()}</small></div></div>)}{state.notes.length===0&&<EmptyState icon="📝" title="Your portfolio starts here" text="Save your first note after a lesson."/>}</div></Card></>
}
function PortfolioChip({emoji,title,value}){return <div className="portfolio-chip"><span>{emoji}</span><div><strong>{value}</strong><small>{title}</small></div></div>}

function Progress({state}) { const p=state.progress; return <><PageHeader eyebrow="MY GROWTH" title="📈 Progress & Learning Gaps" description="A child-friendly view with topic performance, level bridge and recovery signals."/><div className="metric-grid"><Metric icon="🏅" label="XP" value={p.xp} tone="sun"/><Metric icon="🎯" label="Average score" value={`${p.avgScore}%`} tone="aqua"/><Metric icon="🔥" label="Streak" value={`${p.streak || 1} days`} tone="orange"/><Metric icon="🧠" label="Learning level" value={p.avgScore>=80?'Grade-ready':'Growing'} tone="violet"/></div><div className="two-col"><Card><SectionTitle icon="🧠" title="Topic-wise performance"/><Bar label="Plants & EVS" value={Math.max(25,p.avgScore||60)} emoji="🌱"/><Bar label="Maths" value={Math.max(20,(p.avgScore||45)-4)} emoji="➗"/><Bar label="English" value={Math.max(30,(p.avgScore||52)+7)} emoji="🔤"/><Bar label="Vocabulary" value={Math.max(25,(p.avgScore||48)+12)} emoji="🗣️"/><div className="gap-alert">🔎 <strong>Recovery suggestion:</strong> practise the lowest bar next with a bilingual micro-lesson.</div></Card><Card><SectionTitle icon="🗺️" title="Bridge-to-grade pathway"/><div className="bridge-stack"><Bridge label="Baseline" value={35} text="Know what the learner already understands"/><Bridge label="Bridge" value={62} text="Connect prerequisite concepts"/><Bridge label="Grade-ready" value={p.avgScore>=80?100:78} text="Move to the expected curriculum level"/></div></Card></div><Card><SectionTitle icon="🧪" title="Daily three-question exit ticket" subtitle="Frontend demo of the diagnostic-to-recovery loop."/><div className="exit-grid">{['What did you learn?','What was hard?','What should we practise next?'].map((q,i)=><div key={q}><span>Q{i+1}</span><strong>{q}</strong><button className="soft-btn">Answer</button></div>)}</div></Card><Card><SectionTitle icon="🛠️" title="Mistake analysis & recovery engine"/><div className="recovery-grid"><Recovery icon="❌" title="Mistake" text="Question 3: plant part"/><Recovery icon="🔍" title="Cause" text="Vocabulary gap"/><Recovery icon="📚" title="Recovery" text="Picture + audio card"/><Recovery icon="✅" title="Retry" text="1 adaptive question"/></div></Card></> }
function Bridge({label,value,text}){return <div className="bridge-item"><div><strong>{label}</strong><small>{text}</small></div><div className="level-progress"><i style={{width:`${value}%`}}/></div><b>{value}%</b></div>}
function Recovery({icon,title,text}){return <div className="recovery-card"><span>{icon}</span><strong>{title}</strong><p>{text}</p></div>}
function Achievements({state}) { const badges=[['🌟','Quick Learner','Reach 50 XP'],['🔥','Streak Star','Build a 3-day streak'],['🎯','Quiz Master','Complete 3 quizzes'],['🚀','Super Star','Reach 100 XP'],['🎨','Creative Learner','Make 3 learning assets'],['🌈','Language Explorer','Use bilingual learning']]; return <><PageHeader eyebrow="CELEBRATE" title="🏆 Achievements" description="Primary-friendly rewards make progress visible without turning learning into pressure."/><div className="achievement-grid">{badges.map(([icon,title,goal])=>{const earned=state.achievements.includes(title); return <Card key={title} className={`achievement-card ${earned?'earned':''}`}><div className="badge-icon">{icon}</div><h3>{title}</h3><p>{goal}</p><span>{earned?'EARNED':'KEEP LEARNING'}</span></Card>})}</div></> }

function ParentCorner({state}) { return <><Card className="parent-hero"><div className="parent-orb">👨‍👩‍👧</div><div><MiniTag tone="pink">PARENT COMPANION</MiniTag><h2>Learning update for {state.profile?.name || 'your child'}</h2><p>Share progress, homework guidance and approved learning insights without exposing unnecessary child data.</p></div></Card><div className="two-col"><Card><SectionTitle icon="📨" title="Approved progress channels"/><div className="channel-grid"><Channel icon="💬" title="SMS update" status="Ready for integration"/><Channel icon="🟢" title="WhatsApp update" status="Ready for integration"/><Channel icon="🔊" title="Voice report" status="Browser demo"/><Channel icon="📄" title="PDF report" status="UI ready"/></div></Card><Card><SectionTitle icon="🧭" title="Parent homework guidance"/><div className="guidance"><p>“Today, ask your child to explain one plant part in their own words.”</p><button className="soft-btn">✨ Generate another tip</button></div></Card></div><Card><SectionTitle icon="📊" title="Family-friendly progress"/><div className="bar-list"><Bar label="Learning consistency" value={Math.min(100,55+state.progress.streak*8)} emoji="🔥"/><Bar label="Quiz confidence" value={state.progress.avgScore||42} emoji="🎯"/><Bar label="Lesson activity" value={Math.min(100,state.progress.lessons*20+20)} emoji="📚"/></div></Card></> }
function Channel({icon,title,status}){return <div className="channel"><span>{icon}</span><div><strong>{title}</strong><small>{status}</small></div><CheckCircle2 size={15}/></div>}

function SettingsPage({state,update,setToast}) { const [saved,setSaved]=useState(false); const [dialect,setDialect]=useState(state.profile?.dialect||'Standard'); const save=()=>{update({profile:{...state.profile,dialect}});setSaved(true);setToast('Language settings saved');setTimeout(()=>setSaved(false),1500)}; return <><PageHeader eyebrow="CONTROL CENTRE" title="⚙️ Settings & Safe Use" description="Presentation view of consent, language, engine and child-safety controls."/><div className="two-col"><Card><SectionTitle icon="🌍" title="Language & dialect"/><label>Preferred language<select value={state.profile?.language||'Tamil'} onChange={e=>update({profile:{...state.profile,language:e.target.value}})}>{LANGUAGES.map(x=><option key={x}>{x}</option>)}</select></label><label>Local dialect<select value={dialect} onChange={e=>setDialect(e.target.value)}><option>Standard</option><option>Village variant</option><option>Teacher verified</option></select></label><button className="primary-btn" onClick={save}>{saved?<CheckCircle2 size={17}/>:<SaveIcon/>}{saved?'Saved':'Save language setup'}</button></Card><Card><SectionTitle icon="🛡️" title="Child-safe controls"/><ToggleRow title="No advertisements" on/><ToggleRow title="No unrestricted external content" on/><ToggleRow title="Teacher-guided student use" on/><ToggleRow title="Consent for voice recording" on/><ToggleRow title="No continuous student tracking" on/></Card></div><Card><SectionTitle icon="🔁" title="Engine preference"/><div className="preference-row">{[['auto','🔁','Auto fallback'],['online','☁️','Online-first'],['offline','📴','Offline-first']].map(([id,e,t])=><button key={id} className={`pref-card ${(state.engineMode||'auto')===id?'selected':''}`} onClick={()=>update({engineMode:id})}><span>{e}</span><strong>{t}</strong><small>{id==='auto'?'Recommended for demo':id==='online'?'Best when connected':'Best for airplane-mode demo'}</small></button>)}</div></Card></> }
function SaveIcon(){return <CheckCircle2 size={17}/>}
function ToggleRow({title,on}){return <div className="toggle-row-simple"><span>{title}</span><div className={`fake-toggle ${on?'on':''}`}><i/></div></div>}

function VoiceAssistant({state}) { const [text,setText]=useState(''); const [heard,setHeard]=useState(''); const [listening,setListening]=useState(false); const langMap={Tamil:'ta-IN',English:'en-IN',Hindi:'hi-IN',Telugu:'te-IN',Kannada:'kn-IN',Malayalam:'ml-IN'}; const start=()=>{const R=window.SpeechRecognition||window.webkitSpeechRecognition;if(!R){setHeard('Speech recognition is unavailable in this browser.');return}const r=new R();r.lang=langMap[state.profile?.language]||'en-IN';r.interimResults=false;r.onresult=e=>{const s=e.results[0][0].transcript;setHeard(s);setText(s)};r.onend=()=>setListening(false);r.start();setListening(true)}; const speak=()=>{if(!('speechSynthesis'in window)||!text)return;const u=new SpeechSynthesisUtterance(text);u.lang=langMap[state.profile?.language]||'en-IN';window.speechSynthesis.speak(u)}; return <><PageHeader eyebrow="SPEAK + LISTEN" title="🎙️ AI Voice Assistant" description="Real-time voice assistant, speech-to-text, text-to-speech and pronunciation practice."/><div className="two-col"><Card className="voice-card"><button className={`mic-orb ${listening?'listening':''}`} onClick={start}><Mic size={42}/></button><h3>{listening?'Listening…':'Tap to speak'}</h3><p>{heard || 'Ask a question or practise a sentence.'}</p><div className="role-buttons"><MiniTag tone="green">Speech-to-text</MiniTag><MiniTag tone="purple">Language: {state.profile?.language}</MiniTag></div></Card><Card><SectionTitle icon="🔊" title="Voice explanations"/><label>Your sentence<textarea value={text} onChange={e=>setText(e.target.value)} placeholder="Type a sentence to hear it…"/></label><div className="role-buttons"><button className="primary-btn" onClick={speak}><Volume2 size={17}/> Speak aloud</button><button className="soft-btn" onClick={()=>setText('Plants need sunlight, water and air to grow.')}>Use example</button></div><div className="pron-card">🗣️ <strong>Pronunciation practice</strong><small>Repeat the sentence and ask a teacher/parent to approve the voice lesson.</small></div></Card></div></> }

function BlackboardAssistant() { const [img,setImg]=useState(null); const [status,setStatus]=useState(''); const [text,setText]=useState(''); const [busy,setBusy]=useState(false); const run=async e=>{const file=e.target.files?.[0];if(!file)return;setImg(URL.createObjectURL(file));setBusy(true);setStatus('Reading handwriting…');try{const {createWorker}=await import('tesseract.js');const worker=await createWorker('eng');const {data}=await worker.recognize(file);setText(data.text.trim());await worker.terminate();setStatus('OCR complete');}catch(err){setStatus(`OCR demo could not read this image: ${err.message}`)}finally{setBusy(false)}}; return <><PageHeader eyebrow="AI VISION" title="🪄 Blackboard Assistant" description="Turn blackboard photos and handwritten notes into clean digital learning material."/><Card><label className="upload-box"><Upload size={28}/><strong>Drop or choose a classroom board photo</strong><span>PNG/JPG • OCR demo</span><input type="file" accept="image/*" onChange={run}/></label>{img&&<div className="ocr-grid"><img src={img} alt="Uploaded blackboard"/><div><div className="status-text">{busy?'⏳ ':'✅ '}{status}</div><textarea value={text} onChange={e=>setText(e.target.value)} rows="14" placeholder="OCR text will appear here"/><div className="role-buttons"><button className="soft-btn" onClick={()=>navigator.clipboard?.writeText(text)}>📋 Copy notes</button><MiniTag tone="aqua">Textbook image → lesson</MiniTag></div></div></div>}</Card></> }

function DocumentTool({state,setLoadingAI}) { const [file,setFile]=useState(null); const [text,setText]=useState(''); const [result,setResult]=useState(''); const read=async f=>{setFile(f);setResult('');try{let raw='';if(f.type==='text/plain')raw=await f.text();else raw=`File selected: ${f.name}\n\nUpload extraction is represented in this frontend demo. TXT is read directly; PDF/PPT/DOCX/image pipelines are shown as integration-ready surfaces.`;setText(raw.slice(0,12000))}catch(e){setText(`Could not extract: ${e.message}`)}};const make=async()=>{setLoadingAI(true);const r=await askAI({mode:'lesson',prompt:`Turn this uploaded learning material into a primary-level lesson with key ideas and 3 practice questions:\n${text}`,language:state.profile?.language||'English',engine:state.engineMode||'auto'});setResult(r.text);setLoadingAI(false)}; return <><PageHeader eyebrow="MULTIMODAL AI" title="📄 Explain-Anything Upload" description="PDF, PPT, DOCX and image-to-lesson surfaces — ready for the full multimodal pipeline."/><Card><label className="upload-box"><Paperclip size={28}/><strong>Upload PDF / PPT / DOCX / Image</strong><span>Frontend demonstration of the unified content-ingestion flow</span><input type="file" onChange={e=>e.target.files?.[0]&&read(e.target.files[0])}/></label>{file&&<MiniTag tone="aqua">Selected: {file.name}</MiniTag>}<label className="spaced-label">Extracted / prepared content<textarea value={text} onChange={e=>setText(e.target.value)} rows="10" placeholder="Your learning material will appear here"/></label><button className="primary-btn" disabled={!text.trim()} onClick={make}><Sparkles size={17}/> Convert into primary lesson</button></Card>{result&&<Card className="result-card"><LessonView markdown={result}/></Card>}</> }

function QRScanner() { const [result,setResult]=useState(''); const [running,setRunning]=useState(false); const ref=useRef(null); useEffect(()=>()=>{try{ref.current?.clear()}catch{}},[]); const start=async()=>{try{const {Html5Qrcode}=await import('html5-qrcode');const scanner=new Html5Qrcode('qr-reader');ref.current=scanner;setRunning(true);await scanner.start({facingMode:'environment'},{fps:10,qrbox:220},code=>{setResult(code);scanner.stop().catch(()=>{});setRunning(false)},()=>{})}catch(e){setResult(`Camera error: ${e.message}`);setRunning(false)}};return <><PageHeader eyebrow="SMART CLASSROOM" title="🔳 QR Code Learning" description="A printed QR can become a lesson → quiz → practice flow on a shared tablet."/><Card><div id="qr-reader" className="qr-box">{!running&&<div className="qr-placeholder">🔳<strong>Scan a classroom resource</strong><small>Poster • Primer • Worksheet • Story card</small></div>}</div>{!running&&<button className="primary-btn" onClick={start}><QrCode size={17}/> Start camera</button>}{result&&<div className="scan-result"><strong>QR lesson payload</strong><p>{result}</p><div className="role-buttons"><button className="soft-btn">📚 Open lesson</button><button className="soft-btn">🎯 Start quiz</button><button className="soft-btn">🎮 Practice</button></div></div>}</Card></> }

function TeacherDashboard({state,update}) { const [className,setClassName]=useState(''); const [assignment,setAssignment]=useState(''); const create=()=>{if(!className.trim())return;update({classes:[...state.classes,{id:Date.now(),name:className,students:24}]});setClassName('')};const addAssignment=()=>{if(!assignment.trim())return;update({assignments:[...state.assignments,{id:Date.now(),title:assignment,status:'Posted'}]});setAssignment('')};return <><PageHeader eyebrow="TEACHER CONTROL ROOM" title="🧑‍🏫 Teacher Dashboard" description="Class creation, stream, assignments, learning gaps, attendance, video and attention alerts in one view."/><div className="metric-grid"><Metric icon="👥" label="Classes" value={state.classes.length||1} tone="aqua"/><Metric icon="📝" label="Assignments" value={state.assignments.length||2} tone="pink"/><Metric icon="🎯" label="Avg. score" value={`${state.progress.avgScore||68}%`} tone="sun"/><Metric icon="🔥" label="Attention alerts" value="3" tone="orange"/></div><div className="teacher-grid"><Card><SectionTitle icon="🏫" title="Classroom + batch creation"/><div className="inline-form"><input value={className} onChange={e=>setClassName(e.target.value)} placeholder="Class 5-A / Batch 2"/><button className="primary-btn" onClick={create}><Plus size={16}/> Create</button></div>{state.classes.map(c=><div className="list-row" key={c.id}><strong>{c.name}</strong><span>{c.students} students</span></div>)}</Card><Card><SectionTitle icon="📝" title="Assignment posting"/><div className="inline-form"><input value={assignment} onChange={e=>setAssignment(e.target.value)} placeholder="Plants worksheet"/><button className="primary-btn" onClick={addAssignment}><Plus size={16}/> Post</button></div>{state.assignments.map(a=><div className="list-row" key={a.id}><strong>{a.title}</strong><span>{a.status}</span></div>)}</Card><Card><SectionTitle icon="🚨" title="Students-needing-attention alerts"/><AlertRow who="Riya" issue="Maths fraction gap" level="Needs remedial"/><AlertRow who="Aman" issue="3 missed assignments" level="Follow up"/><AlertRow who="Kavi" issue="Low vocabulary confidence" level="Practice"/></Card><Card><SectionTitle icon="🎬" title="Classroom video learning"/><div className="video-demo"><div className="video-thumb">▶</div><div><strong>Upload → package → quiz</strong><p>Video summary, vocabulary, linked homework and download-ready lesson.</p><button className="soft-btn">Upload classroom video</button></div></div></Card></div><Card><SectionTitle icon="📊" title="Topic-wise + learning-gap dashboard"/><div className="bar-list"><Bar label="EVS concept mastery" value={state.progress.avgScore||72} emoji="🌱"/><Bar label="Maths foundations" value={Math.max(25,(state.progress.avgScore||65)-8)} emoji="➗"/><Bar label="Language confidence" value={Math.min(100,(state.progress.avgScore||60)+10)} emoji="🌍"/></div></Card><Card><SectionTitle icon="✅" title="Teacher content review checklist"/><div className="check-grid">{['Language verified','Culturally suitable example','Age appropriate','Voice lesson approved','Entertainment reviewed','Homework has answer path'].map(t=><div key={t}>✓ {t}</div>)}</div></Card></> }
function AlertRow({who,issue,level}){return <div className="alert-row"><div className="alert-avatar">{who[0]}</div><div><strong>{who}</strong><small>{issue}</small></div><MiniTag tone="warning">{level}</MiniTag></div>}

function ParentDashboardFull({state}) { return <><PageHeader eyebrow="PARENT COMPANION" title="👨‍👩‍👧 Parent Dashboard" description="Progress updates, homework guidance and communication surfaces — designed around approved data sharing."/><ParentCorner state={state}/></> }

function AdminDashboard({state}) { return <><PageHeader eyebrow="SCHOOL + GOVERNMENT MONITORING" title="🏫 Aggregate Progress Centre" description="A privacy-aware demonstration of school, section, language, batch and anonymized impact reporting."/><div className="admin-banner"><div><MiniTag tone="green">ANONYMIZED REPORTING</MiniTag><h2>See patterns, not private child details.</h2><p>Authorized dashboards can monitor progress, learning gaps, resources and teacher-training needs using aggregate views.</p></div><div className="admin-number"><strong>1</strong><span>demo school</span></div></div><div className="metric-grid admin"><Metric icon="🏫" label="Sections" value="6" tone="aqua"/><Metric icon="🌍" label="Language groups" value="4" tone="pink"/><Metric icon="👩‍🏫" label="Teachers" value="18" tone="sun"/><Metric icon="📈" label="Avg. progress" value={`${state.progress.avgScore||68}%`} tone="violet"/></div><div className="two-col"><Card><SectionTitle icon="📊" title="Monitoring reports"/><ReportRow title="Class-wise progress" status="Ready"/><ReportRow title="Section + batch report" status="Ready"/><ReportRow title="Language group report" status="Ready"/><ReportRow title="Learning impact report" status="Anonymized"/><ReportRow title="Resource / training needs" status="Ready"/></Card><Card><SectionTitle icon="🔐" title="Governance"/><div className="governance-list"><p>✅ Authorized access control</p><p>✅ Anonymous government reporting</p><p>✅ Responsible AI content review</p><p>✅ Low-confidence translation alert</p><p>✅ Native-speaker correction loop</p></div></Card></div></> }
function ReportRow({title,status}){return <div className="report-row"><strong>{title}</strong><MiniTag tone="soft">{status}</MiniTag><ChevronRight size={15}/></div>}

function SafeTabHub({state}) { const [locked,setLocked]=useState(false); const [sos,setSos]=useState(false); const [msg,setMsg]=useState('Please return this tablet to the school office. Device ID: VEDAI-DEMO-019.'); return <><PageHeader eyebrow="DEVICE + STUDENT SAFETY" title="🛡️ SafeTab + SOS" description="Frontend demonstration of the controlled device recovery and student safety workflows."/><div className="safety-alert"><ShieldCheck size={23}/><div><strong>Authorized school-device layer</strong><p>GPS/recovery actions are shown as a UI prototype and should require explicit school authorization in the production system.</p></div></div><div className="two-col"><Card className="safety-card"><SectionTitle icon="📱" title="SafeTab device recovery"/><div className="device-id"><span>Tablet ID</span><strong>VEDAI-DEMO-019</strong><small>QR label: #V-019</small></div><div className="safety-actions"><button className="primary-btn" onClick={()=>setLocked(v=>!v)}>{locked?'🔓 Unlock demo tablet':'🔒 Lock missing tablet'}</button><button className="soft-btn"><MapPin size={16}/> Show last known location</button><button className="soft-btn"><QrCode size={16}/> View QR identification</button></div>{locked&&<div className="lock-banner">🔒 <strong>Tablet lock screen active</strong><span>Return-to-school message is shown to the finder.</span></div>}<label>Return-to-school message<textarea value={msg} onChange={e=>setMsg(e.target.value)}/></label></Card><Card className="sos-card"><SectionTitle icon="🚨" title="Student safety support"/><div className={`sos-orb ${sos?'active':''}`}><span>🚨</span><strong>{sos?'ALERT SENT':'SOS'}</strong><small>{sos?'Demo notification chain triggered':'Press only in an emergency'}</small></div><button className="sos-btn" onClick={()=>setSos(true)}>Activate demo SOS</button><div className="contact-stack"><span>👩‍🏫 Teacher alert</span><span>👨‍👩‍👧 Parent / guardian</span><span>🏫 School safety contact</span><span>📊 Incident dashboard</span></div></Card></div><Card><SectionTitle icon="🔐" title="SafeTab production guardrails"/><div className="guardrail-grid"><Rule icon="✅" title="Teacher authorization" text="Recovery and location actions require authorized school access."/><Rule icon="📴" title="Offline sync" text="Missing-device events can queue locally until a trusted network appears."/><Rule icon="🆔" title="Unique device ID" text="Every tablet carries a unique ID and QR identification label."/><Rule icon="🧒" title="Student safety" text="Emergency support is separate from continuous tracking."/></div></Card></> }

function EmptyState({icon,title,text}){return <div className="empty-state"><div>{icon}</div><strong>{title}</strong><p>{text}</p></div>}

export default App
