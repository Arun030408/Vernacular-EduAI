# Vernacular EduAI — 160 Feature Index

Every numbered feature below is represented in the `/features` frontend Feature Center.

1. Culture-Aware Hindi-to-Tribal Language Translator
2. Ho Language Learning Support
3. Mundari Language Learning Support
4. Santhali Language Learning Support
5. Hindi Teacher Support Interface
6. Khortha Language Support — Future Expansion
7. Student Baseline Assessment
8. Learning-Level Identification
9. Learning-Gap Analysis
10. Bridge-to-Grade Learning Pathway
11. Personalized Learning Material Recommendation
12. Diagnostic Assessment Engine
13. Topic-Wise Performance Analysis
14. Student Progress Tracking
15. Daily Three-Question Exit Ticket
16. Mistake Analysis and Recovery Engine
17. Personalized Remedial Learning Path
18. Smart Homework Generator
19. Adaptive Practice Activities
20. Automatic Quiz Evaluation
21. Bilingual Quiz Feedback
22. Multiple-Choice Questions
23. True-or-False Activities
24. Match-the-Following Activities
25. Fill-in-the-Blanks Activities
26. Short-Answer Questions
27. Image-Based Questions
28. Diagram-Based Learning Activities
29. Visual Diagram Lessons
30. Digital Textbook Lessons
31. Bilingual Audio Lessons
32. Voice Explanations
33. Teacher Voice-to-Lesson Generator
34. Teacher Voice-to-Text Conversion
35. Real-Time Voice Assistant
36. Speech-to-Text Support
37. Text-to-Speech Support
38. Pronunciation Practice
39. Teacher/Parent Approved Voice Lessons
40. Picture-Based Flashcards
41. Audio Flashcards
42. Spaced-Repetition Flashcards
43. Vocabulary Learning Games
44. Educational Mini-Games
45. Gamification with XP and Badges
46. Attendance Streaks
47. Teacher-Supervised Leaderboards
48. Tribal Story-to-Lesson Generator
49. EduFun AI Stories
50. EduFun AI Rhymes
51. Vocabulary Songs
52. Picture Stories
53. Rhyme-to-Practice Activities
54. Teacher-Reviewed Entertainment Content
55. Limited Screen-Time Learning Mode
56. QR-Code-Based Lessons
57. QR Code to Lesson, Quiz and Practice Flow
58. AI Blackboard Assistant
59. Blackboard Photo to Digital Notes
60. Handwritten Notes to Digital Content
61. Textbook Image to Lesson
62. PDF-to-Lesson Generator
63. PPT-to-Lesson Generator
64. DOCX-to-Lesson Generator
65. Image-to-Lesson Generator
66. Explain-Anything Upload Feature
67. Lesson Plan Generator
68. Worksheet Generator
69. Activity Generator
70. Quiz Generator
71. Homework Generator
72. Classroom Video Upload
73. Video-to-Learning Package
74. Video Summary Generator
75. Video Vocabulary Generator
76. Video-Linked Quiz and Homework
77. Teacher Classroom and Batch Creation
78. Class Stream and Announcements
79. Assignment Posting
80. Due-Date Management
81. Student Submission Review
82. Student Learning Portfolio
83. Teacher Dashboard
84. Student-Level Dashboard
85. Topic-Wise Dashboard
86. Learning-Gap Dashboard
87. Homework and Quiz Dashboard
88. Attendance Dashboard
89. Students-Needing-Attention Alerts
90. Class-Wise Progress Report
91. Parent Companion Dashboard
92. Parent SMS Progress Updates
93. Parent WhatsApp Progress Updates
94. Parent Voice Progress Reports
95. Parent PDF Progress Reports
96. Parent Homework Guidance
97. School-Level Progress Monitoring
98. Class, Section, Language and Batch Reports
99. Authorized Government Aggregate Reports
100. Anonymized Learning Impact Reports
101. Resource and Teacher-Training Need Reports
102. Offline-First Learning System
103. Offline Progressive Web App
104. Offline Content Packs
105. Local Device Storage
106. Shared-Tablet Multi-Student Profiles
107. Airplane-Mode Learning Support
108. Offline Quiz and Homework Storage
109. Offline Attendance Storage
110. Offline Progress Storage
111. Wi-Fi Direct Synchronization
112. Local Wi-Fi Synchronization
113. School-in-a-Box Local Hub
114. Local School Server
115. Conflict-Safe Data Synchronization
116. Optional Cloud Backup
117. Online Learning Mode Where Network Is Available
118. Recorded Online Lesson Download
119. Three-Day Offline Classroom Model
120. Two-Day Online/Recorded Learning Model
121. Affordable Android 9+ Support
122. Lite Mode for 2 GB RAM Tablets
123. Preloaded Tribal Books and Primers
124. Local Vocabulary and Audio Library
125. Teacher Training Kit
126. Teacher Content Review Checklist
127. Community and Native-Speaker Verification
128. Verified Tribal-Language Glossary
129. Local Dialect Selection
130. Local Cultural Context Adaptation
131. Village, Forest, Farming and Market-Based Examples
132. SafeTab Device Security
133. SafeTab Missing-Tablet Recovery
134. Last Known Device Location
135. Teacher-Authorized GPS Device Recovery
136. Offline Missing-Device Recovery Sync
137. Tablet Lock Screen for Missing Devices
138. Return-to-School Message
139. Unique Tablet Device ID
140. Tablet QR Identification Label
141. SafeTab SOS Emergency Alert
142. Student Safety Support Button
143. Teacher Emergency Alert Option
144. Parent/Guardian Emergency Notification
145. School Safety Contact Alert
146. Emergency Incident Dashboard
147. Student Data Privacy Protection
148. Consent-Based Voice Recording
149. Consent-Based Device Safety Access
150. Teacher-Guided Student Use
151. Child-Safe Content Review
152. No Advertisement Learning Environment
153. No Unrestricted External Content
154. No Continuous Student Tracking
155. Authorized Access Control
156. Secure Child Video Storage
157. Anonymous Government Reporting
158. Responsible AI Content Review
159. Low-Confidence Translation Review Alert
160. Native-Speaker Translation Correction Loop
