# Vernacular EduAI — Frontend Presentation Portal

Vernacular EduAI is a primary-school vernacular pedagogy portal designed for a **dual-engine learning model**:

- **Offline Local Engine:** cached lessons, local content packs, quizzes, homework, notes, attendance and progress can continue without the internet.
- **Online AI Engine:** when connectivity is available, the portal can call the Netlify AI function for richer lesson generation, tutoring and translation, while preserving the local fallback.

## What is included

This presentation build exposes **22 solution modules and all 160 feature titles** from the Vernacular EduAI concept. The Feature Center is searchable, numbered and grouped so each feature can be shown during a PPT/demo walkthrough.

Key demo routes:

- `/` — child-friendly role login
- `/dashboard` — primary student home
- `/features` — all 160 feature surfaces
- `/dual-engine` — offline + online architecture, sync flow and classroom model
- `/lessons` — AI Lesson Maker
- `/tutor` — AI Tutor
- `/quiz` — smart quiz + automatic evaluation
- `/translator` — Hindi ↔ vernacular language bridge
- `/flashcards` — picture/audio/spaced repetition cards
- `/stories` — EduFun stories, rhymes and mini-games
- `/voice` — speech-to-text + text-to-speech UI
- `/blackboard` — blackboard OCR demo
- `/documents` — upload → lesson workflow
- `/qr` — QR lesson flow
- `/teacher` — teacher classroom control room
- `/parent-dashboard` — parent companion
- `/admin` — school/government aggregate reporting
- `/safetab` — SafeTab recovery + SOS UI
- `/settings` — language, dialect, engine and child-safety controls

## Frontend scope

This build is intentionally **presentation-first**. All feature surfaces are represented in the frontend so the complete solution can be demonstrated in a PPT. Hardware, messaging, GPS recovery, school-server synchronization and production government integrations are represented as controlled UI flows and are **not claimed as production backends**.

The portal uses browser/local capabilities for the demo, including localStorage, service-worker caching, speech APIs and browser camera/OCR integrations where supported.

## Run locally

```bash
npm install
npm run dev
```

Production build:

```bash
npm run build
```

The project uses Vite + React and is configured for Netlify with `dist` as the publish directory.

## Optional online AI

The frontend automatically falls back to the local demo engine when the AI function is unavailable.

For Netlify, add these environment variables to the site settings:

```text
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-5.6-luna
```

Do not commit the API key to GitHub.

## GitHub + Netlify deployment

1. Create a GitHub repository.
2. Push this folder to the repository.
3. In Netlify, import the GitHub repository.
4. Keep the build command as `npm run build` and publish directory as `dist`.
5. Netlify will read `netlify.toml` and use the SPA rewrite.
6. Add `OPENAI_API_KEY` only in Netlify environment variables when online AI is required.

### Command-line Git setup

```bash
git init
git add .
git commit -m "Build Vernacular EduAI presentation portal"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/vernacular-eduai.git
git push -u origin main
```

Then connect that repository from Netlify for continuous deployment.

## Demo note

The sign-in screen is a **demo role gate**, not production authentication. It supports Student, Teacher, Parent/Guardian and School/Admin views without requiring a real account.
