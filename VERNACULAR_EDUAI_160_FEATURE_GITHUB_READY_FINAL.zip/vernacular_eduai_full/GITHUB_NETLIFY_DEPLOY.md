# GitHub + Netlify deployment checklist

## GitHub

From the project root:

```bash
git init
git add .
git commit -m "Vernacular EduAI frontend"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/vernacular-eduai.git
git push -u origin main
```

Or use GitHub Desktop to publish the local repository.

## Netlify

Use **Add new project → Import an existing project → GitHub** and select the repository.

The checked-in `netlify.toml` already defines:

```toml
[build]
  command = "npm run build"
  publish = "dist"
  functions = "netlify/functions"
```

The SPA rewrite is also included so direct links such as `/features` and `/dual-engine` resolve correctly.

## Online AI

Set these in Netlify environment variables:

```text
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5.6-luna
```

The frontend remains usable without the key because `askAI()` falls back to the local demo engine.

## Presentation mode

For the PPT demo, open `/features` and search any named feature, then open `/dual-engine` to show the architecture and the five-day offline/online classroom model.
