export default async (req) => {
  if (req.method !== 'POST') return new Response('Method Not Allowed', { status: 405 })

  const apiKey = process.env.OPENAI_API_KEY
  if (!apiKey) {
    return new Response(JSON.stringify({
      ok: false,
      error: 'OPENAI_API_KEY is not configured. The frontend will use its built-in demo AI fallback.'
    }), { status: 200, headers: { 'content-type': 'application/json' } })
  }

  try {
    const body = await req.json()
    const model = process.env.OPENAI_MODEL || 'gpt-5.6-luna'
    const language = body.language || 'English'
    const mode = body.mode || 'tutor'
    const prompt = body.prompt || ''
    const context = body.context || ''

    const instructions = `You are Vernacular EduAI, a warm, child-safe primary-school tutor for Grades 1-5.\n` +
      `Respond in ${language}. Use simple age-appropriate words, short sections, examples, and encouraging language.\n` +
      `Mode: ${mode}. Never provide unsafe instructions or adult content. Prefer educational clarity over verbosity.`

    const input = `Context:\n${context}\n\nStudent request:\n${prompt}`

    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({ model, instructions, input })
    })

    const data = await response.json()
    if (!response.ok) {
      return new Response(JSON.stringify({ ok: false, error: data?.error?.message || 'AI request failed' }), {
        status: response.status,
        headers: { 'content-type': 'application/json' }
      })
    }

    return new Response(JSON.stringify({ ok: true, text: data.output_text || '' }), {
      status: 200,
      headers: { 'content-type': 'application/json' }
    })
  } catch (error) {
    return new Response(JSON.stringify({ ok: false, error: error.message || 'Unknown AI error' }), {
      status: 500,
      headers: { 'content-type': 'application/json' }
    })
  }
}
